from bs4 import BeautifulSoup

html_file = open('/Users/polinavodovatova/Downloads/exam19/ПОЛИТИКЭР | Адыгэ Макъ.html', 'r', encoding='utf-8')
htmlsrc = html_file.read()
html_file.close()

bsoup = BeautifulSoup(htmlsrc, "lxml")
extracted_items = bsoup.findAll("div", {"class":"box"})

corpus_set = set()

for item in extracted_items:
    itemtext = item.get_text().lower()
    itemlst = itemtext.split()
    itemset = set(itemlst)
    corpus_set |= itemset


adyghe_words = open('/Users/polinavodovatova/Downloads/exam19/adyghe-unparsed-words.txt', 'r', encoding='utf-8')

adyghe_wordsset = set()

for line in adyghe_words:
    adyghe_wordsset.add(line.replace('\n', ''))
adyghe_words.close()


common_words = adyghe_wordsset & corpus_set

fout = open('wordlist.txt', 'w', encoding='utf-8')
for word in common_words:
    fout.write(word+'\n')
fout.close()

